package IfElseStatements;

public class Projector {
    public static void main(String[] args) {

        if ( 4 == 5){
            System.out.println("Ok then");

        }
        else{
            System.out.println("Thank You");
        }


        if ( 2<90){
            System.out.println("perfect");
        }
















    }







}
