package Loops;

public class LoopRiverseExample {

    public static void main(String[] args) {

        for(int i =10; i>=0; i--){
            System.out.print(i +", ");

        }








    }
}
