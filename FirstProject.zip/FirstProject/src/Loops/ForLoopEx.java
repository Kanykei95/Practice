package Loops;

public class ForLoopEx {
    public static void main(String[] args) {

        char c = 'a';
       for (;c  != 'z';)
        {
            System.out.println(""+c);
            c+=1;
        }
    }
}
