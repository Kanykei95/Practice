package Loops;

public class DoWhileLoop {
    public static void main(String[] args) {
        int num=1;

        do {
            System.out.println(num);
            num++;

        }while(num<10);
    }
}
