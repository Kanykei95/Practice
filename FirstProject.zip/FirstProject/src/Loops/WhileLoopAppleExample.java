package Loops;

public class WhileLoopAppleExample {
    public static void main(String[] args) {

        int apples =1;

        while(apples <= 10){
            System.out.println("Eating an apple");
            apples++; //increment
        }
        System.out.println("No more apples: " );
    }
}
