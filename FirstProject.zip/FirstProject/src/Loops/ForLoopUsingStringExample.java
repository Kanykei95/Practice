package Loops;

public class ForLoopUsingStringExample {
    public static void main(String[] args) {

        String[] fruits = new String [3];
        fruits [0] = "apples";
        fruits [1]= "pears";
        fruits [2] = "oranges";

        for (int i = 0; i<3; i++){
            System.out.println(fruits[0]);
        }
    }
}
