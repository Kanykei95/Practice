package Loops;

public class ForLoop {
    public static void main(String[] args) {
        for (int i= 0; i < 5; i++) {
            System.out.println("Hello world" +i);

        }
        System.out.println("Between");

        for (int i = 0; i<=5; i++){
            System.out.println("bye world"+i);
        }

        System.out.println("END");










    }
}
