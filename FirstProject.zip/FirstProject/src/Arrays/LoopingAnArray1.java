package Arrays;

import java.util.Arrays;

public class LoopingAnArray1 {
    public static void main(String[] args) {
        String [] names = {"John","Adam", "Don"};

        for(int i = 0; i< names.length; i++){

            System.out.println("Name: " + names[i]);
        }
    }
}
