package Arrays;

public class LoopingAnArray2 {
    public static void main(String[] args) {
        String[] names = {"John","Adam","Don"};
        for (String item: names) {



                System.out.println("Name: " + item);
            }
        }
    }

