package Arrays;

import java.util.Arrays;

public class Check {
    public static void main(String[] args) {
        int[] ints = {2,15,7,1,3};
        Arrays.sort(ints);
        // Syntax for sorting Array elements
        System.out.println(Arrays.toString(ints));
        System.out.println(ints); //[I@7a46a697
    }
}
