package Strings;

import java.util.Scanner;

public class OlgaSlackTask4 {
    public static void main(String[] args) {
        //Ask from a user for any string.
        //-Printout this string in lower case.
        //-Printout this string in upper case.

        Scanner input = new Scanner (System.in);

        String word = input.nextLine();

        System.out.println(word.toLowerCase());
        System.out.println();
        System.out.println(word.toUpperCase());











    }
}
