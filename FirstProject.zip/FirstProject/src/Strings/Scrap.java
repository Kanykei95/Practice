package Strings;

public class Scrap {
    public static void main(String[] args) {
        String word = "java";
        String word2 = "if fun";
        char c = word.charAt(1);
       char d = word.charAt(2);
        char f = word2.charAt(0);
        System.out.println(c);
        System.out.println("" + c + f);











    }




}
