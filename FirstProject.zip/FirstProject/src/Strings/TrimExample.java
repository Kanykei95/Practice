package Strings;

public class TrimExample {
    public static void main(String[] args) {
        String string1 = "            Love around the world               ";

        String string2 = string1.trim();

        System.out.println("The string starts " + string1 + " end ends");
        System.out.println("The string starts " + string2+ " end ends");
    }
}
