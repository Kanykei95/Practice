package Strings;

public class KanaIsTiered {
    public static void main(String[] args) {
        String word = " Kana is Tiered  ";
        String check = word.replace(" ","");
        System.out.println(check);
    }
}
