package Strings;

public class OlgaSlackTask3 {
    public static void main(String[] args) {
        //In your program you will have this string
        //«          Amanda wants apples          ».
        //Print out this string without spaces on front of and in the end of string.

        String sen = "           Amanda wants apples              ";

        System.out.println(sen.trim());









    }
}
