package Strings;

import java.util.Scanner;

public class CharAt {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String enteredByUser = input.nextLine();

        char thirdLetter = enteredByUser.charAt(3);
        char fifthLetter = enteredByUser.charAt(5);
        char sixthLetter = enteredByUser.charAt(6);

        System.out.println(thirdLetter);
        System.out.println(fifthLetter);
        System.out.println(sixthLetter);












    }
}
