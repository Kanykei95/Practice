package IntroToJavaPractice;

import java.util.Scanner;

public class Task6 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int a = input.nextInt();
        int b = input.nextInt();
        boolean result = a==b;
        System.out.println(result);








    }









}
    //Write a program that will ask user to enter two numbers. Declare a boolean with the following
    // value: numberOne == numberTwo. Print the resulting boolean. > input: 4, 5>output: false