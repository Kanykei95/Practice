package IntroToJavaPractice;

public class edmodo {
    public static void main(String[] args) {

        int a = 3;

        int b = 10;

        System.out.print( a % b );

    }
}
