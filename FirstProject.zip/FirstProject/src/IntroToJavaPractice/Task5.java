package IntroToJavaPractice;

import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char char1 = input.nextLine().charAt(0);
        char char2 = input.nextLine().charAt(0);
        boolean result = (char1>char2);
        System.out.println(result);







    }
}
