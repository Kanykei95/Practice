package IntroToJavaPractice;

import java.util.Scanner;

public class Task4 {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);

        boolean a = input.nextBoolean();
        System.out.println(!a);





    }
}
