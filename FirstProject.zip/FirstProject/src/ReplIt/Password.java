package ReplIt;

import java.util.Scanner;

//public class Password {
    //public static void main(String[] args) {
        //Scanner input = new Scanner (System.in);
       // System.out.println("Please enter a password: ");
       // String n1 = input.nextLine();

       // if (n1.length()<8){
            //System.out.println("Password should contain minimum 8 characters ");

       // }else(n1.contains() )

    //}
//}

    //if(name.charAt(0) >= 65 && name.charAt(0) <= 90){