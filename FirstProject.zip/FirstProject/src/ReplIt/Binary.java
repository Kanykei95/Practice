package ReplIt;

import java.util.Scanner;

public class Binary {
    public static void main(String[] args) {

    }
}



