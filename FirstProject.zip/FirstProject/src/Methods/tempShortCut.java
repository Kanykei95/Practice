package Methods;

public class tempShortCut {
    public static void main(String[] args) {
            //ShortCut for this class and print as is in the class listed below....
       TaskPracticeVoidMethod.printOddNumber();


    }
}
