package variables;

public class Pet {
    public static void main(String[] args) {
        System.out.println("Whats up");







    }












}